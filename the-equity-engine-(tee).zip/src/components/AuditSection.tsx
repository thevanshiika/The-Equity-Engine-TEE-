import React, { useState } from 'react';
import { 
    Upload, 
    FileSpreadsheet, 
    ChevronRight, 
    Activity, 
    AlertCircle, 
    CheckCircle2,
    BarChart3,
    Download,
    Database,
    ShieldCheck,
    FileText
} from 'lucide-react';
import Papa from 'papaparse';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    BarChart, 
    Bar, 
    XAxis, 
    YAxis, 
    CartesianGrid, 
    Tooltip, 
    ResponsiveContainer,
    Cell
} from 'recharts';

export default function AuditSection() {
    const [file, setFile] = useState<File | null>(null);
    const [data, setData] = useState<any[]>([]);
    const [headers, setHeaders] = useState<string[]>([]);
    const [analyzing, setAnalyzing] = useState(false);
    const [results, setResults] = useState<any>(null);
    
    const [config, setConfig] = useState({
        protectedAttribute: '',
        targetAttribute: ''
    });

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            setFile(selectedFile);
            Papa.parse(selectedFile, {
                header: true,
                complete: (results) => {
                    setData(results.data);
                    setHeaders(Object.keys(results.data[0] || {}));
                }
            });
        }
    };

    const runAudit = async () => {
        if (!config.protectedAttribute || !config.targetAttribute) return;
        setAnalyzing(true);
        try {
            const resp = await fetch('/api/scan-bias', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    data,
                    protectedAttribute: config.protectedAttribute,
                    targetAttribute: config.targetAttribute
                })
            });
            const res = await resp.json();
            setResults(res);
        } catch (e) {
            console.error(e);
        } finally {
            setAnalyzing(false);
        }
    };

    return (
        <div className="space-y-8 pb-12">
            {!results ? (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left: Upload & Config */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
                            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                <Upload className="w-5 h-5 text-indigo-400" />
                                Model Pipeline
                            </h3>
                            
                            <label className="group relative flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-slate-800 rounded-2xl cursor-pointer hover:border-indigo-500/50 hover:bg-indigo-500/5 transition-all">
                                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                    <FileSpreadsheet className="w-8 h-8 text-slate-500 mb-3 group-hover:text-indigo-400" />
                                    <p className="text-sm text-slate-400">{file ? file.name : 'Upload .csv dataset'}</p>
                                </div>
                                <input type="file" className="hidden" accept=".csv" onChange={handleFileUpload} />
                            </label>

                            {headers.length > 0 && (
                                <div className="mt-8 space-y-4">
                                    <div className="space-y-2">
                                        <label className="text-xs font-mono text-slate-500 uppercase">Protected Attribute (e.g. Race, Gender)</label>
                                        <select 
                                            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500"
                                            onChange={(e) => setConfig({...config, protectedAttribute: e.target.value})}
                                        >
                                            <option value="">Select Attribute</option>
                                            {headers.map(h => <option key={h} value={h}>{h}</option>)}
                                        </select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-mono text-slate-500 uppercase">Target Variable (Prediction/Label)</label>
                                        <select 
                                            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500"
                                            onChange={(e) => setConfig({...config, targetAttribute: e.target.value})}
                                        >
                                            <option value="">Select Target</option>
                                            {headers.map(h => <option key={h} value={h}>{h}</option>)}
                                        </select>
                                    </div>
                                    <button 
                                        disabled={!config.protectedAttribute || !config.targetAttribute || analyzing}
                                        onClick={runAudit}
                                        className="w-full mt-4 py-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2"
                                    >
                                        {analyzing ? (
                                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                        ) : (
                                            <>Start Fairness Audit <ChevronRight className="w-4 h-4" /></>
                                        )}
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Right: Data Preview */}
                    <div className="lg:col-span-2">
                        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 h-[480px] flex flex-col overflow-hidden">
                            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                <Activity className="w-5 h-5 text-emerald-400" />
                                Data Stream
                            </h3>
                            {data.length > 0 ? (
                                <div className="flex-1 overflow-auto rounded-xl border border-slate-800">
                                    <table className="w-full text-left text-sm">
                                        <thead className="bg-slate-800 text-slate-400 sticky top-0">
                                            <tr>
                                                {headers.slice(0, 6).map(h => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-800">
                                            {data.slice(0, 10).map((row, i) => (
                                                <tr key={i} className="hover:bg-slate-800/30">
                                                    {headers.slice(0, 6).map(h => (
                                                        <td key={h} className="px-4 py-3 text-slate-300 truncate max-w-[150px]">{row[h]}</td>
                                                    ))}
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                    <div className="p-4 text-center text-xs text-slate-500 border-t border-slate-800">
                                        Showing 10 of {data.length} records
                                    </div>
                                </div>
                            ) : (
                                <div className="flex-1 flex flex-col items-center justify-center text-slate-600">
                                    <Database className="w-12 h-12 mb-4 opacity-20" />
                                    <p className="text-sm">Awaiting dataset intake...</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            ) : (
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-8"
                >
                    {/* Results Overview */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl flex flex-col items-center gap-4">
                            <div className="text-xs uppercase tracking-widest font-mono text-slate-500">Fairness Score</div>
                            <div className={`text-5xl font-bold ${results?.fairnessScore > 80 ? 'text-emerald-400' : 'text-red-400'}`}>
                                {results?.fairnessScore ? Math.round(results.fairnessScore) : 0}
                            </div>
                        </div>
                        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl col-span-2">
                             <div className="text-xs uppercase tracking-widest font-mono text-slate-500 mb-4">Disparate Impact Ratio</div>
                             <div className="h-2 w-full bg-slate-800 rounded-full mb-2 overflow-hidden relative">
                                <motion.div 
                                    initial={{ width: 0 }}
                                    animate={{ width: `${Math.min(100, (results?.disparateImpact || 0) * 100)}%` }}
                                    className={`h-full ${(results?.disparateImpact || 0) < 0.8 ? 'bg-red-500' : 'bg-emerald-500'}`}
                                />
                                <div className="absolute top-0 left-[80%] h-full w-[2px] bg-white/20" title="Industry Standard (0.8)" />
                             </div>
                             <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                                <span>UNFAIR (0)</span>
                                <span>EQUITY (1.0)</span>
                             </div>
                        </div>
                        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl flex flex-col justify-center">
                            <div className="flex items-center gap-3 mb-2">
                                {(results?.disparateImpact || 0) < 0.8 ? (
                                    <AlertCircle className="w-6 h-6 text-red-500" />
                                ) : (
                                    <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                                )}
                                <span className="font-bold text-white">Status</span>
                            </div>
                            <p className="text-xs text-slate-400">
                                {(results?.disparateImpact || 0) < 0.8 ? 'Bias detected against unprivileged group.' : 'Model meets equity standards.'}
                            </p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* Visualization */}
                        <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl">
                            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                                <BarChart3 className="w-5 h-5 text-indigo-400" />
                                Demographic Disparity
                            </h3>
                            <div className="h-[300px] w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={[
                                        { name: 'Privileged', rate: 1.0 },
                                        { name: 'Unprivileged', rate: isNaN(results?.disparateImpact) ? 0 : results.disparateImpact }
                                    ]}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                                        <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                                        <YAxis stroke="#64748b" fontSize={12} />
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                                        />
                                        <Bar dataKey="rate" radius={[8, 8, 0, 0]}>
                                            {
                                                [{ name: 'Privileged', rate: 1.0 }, { name: 'Unprivileged', rate: results?.disparateImpact || 0 }].map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={index === 0 ? '#6366f1' : (results?.disparateImpact || 0) < 0.8 ? '#ef4444' : '#10b981'} />
                                                ))
                                            }
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Explainability & Actions */}
                        <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl flex flex-col">
                            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                                <FileText className="w-5 h-5 text-indigo-400" />
                                AI Audit Report
                            </h3>
                            <div className="flex-1 overflow-auto prose prose-invert prose-sm max-w-none prose-p:text-slate-400 prose-li:text-slate-400">
                                <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed p-4 bg-slate-950 rounded-xl border border-slate-800">
                                    {results.recommendations}
                                </div>
                            </div>
                            <button 
                                onClick={() => setResults(null)}
                                className="mt-8 py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl transition-all"
                            >
                                Start New Audit
                            </button>
                        </div>
                    </div>

                    {/* Audit Certificate CTA */}
                    <div className="p-8 bg-gradient-to-r from-indigo-600/20 to-purple-600/20 border border-indigo-500/30 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
                        <div className="flex items-center gap-6">
                            <div className="p-4 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-600/40">
                                <ShieldCheck className="w-8 h-8 text-white" />
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-white mb-1">Generate Fairness Certificate</h3>
                                <p className="text-slate-400 text-sm">Download a signed PDF report for your model validation records.</p>
                            </div>
                        </div>
                        <button className="px-8 py-3 bg-white text-indigo-900 font-bold rounded-xl flex items-center gap-2 hover:bg-slate-100 transition-all">
                            <Download className="w-4 h-4" /> Export Certification
                        </button>
                    </div>
                </motion.div>
            )}
        </div>
    );
}
