import React from 'react';
import { motion } from 'framer-motion';
import { 
    Briefcase, 
    Heart, 
    Landmark, 
    Gavel, 
    ShieldCheck, 
    Plus,
    ExternalLink,
    Zap
} from 'lucide-react';

export default function PluginMarketplace() {
    const plugins = [
        {
            icon: <Briefcase className="w-6 h-6 text-blue-400" />,
            title: "Hiring Fairness Pack",
            author: "EquityDAO",
            desc: "Optimized for HR datasets. Enforces the 4/5ths rule and detects ethnic name discrimination.",
            type: "Recruitment"
        },
        {
            icon: <Landmark className="w-6 h-6 text-emerald-400" />,
            title: "Credit Risk Guard",
            author: "OpenFin",
            desc: "Audits loan approval models for redlining and neighborhood proxy biases.",
            type: "FinTech"
        },
        {
            icon: <Heart className="w-6 h-6 text-rose-400" />,
            title: "Health Diagnostic Shield",
            author: "MedFair",
            desc: "Detects diagnostic disparities and resource allocation bias in medical AI.",
            type: "Healthcare"
        },
        {
            icon: <Gavel className="w-6 h-6 text-amber-400" />,
            title: "Recidivism Auditor",
            author: "JusticeTech",
            desc: "High-precision audit for COMPAS-style risk assessment models.",
            type: "Justice"
        }
    ];

    return (
        <div className="space-y-8">
            <header className="flex justify-between items-center">
                <div>
                    <h2 className="text-xl font-bold text-white mb-1">Equity Plugin Hub</h2>
                    <p className="text-slate-400 text-sm">Download community-validated fairness definitions.</p>
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold rounded-xl transition-all">
                    <Plus className="w-4 h-4" /> Register Plugin
                </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {plugins.map((p, i) => (
                    <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                        className="p-6 bg-slate-900 border border-slate-800 rounded-3xl hover:border-indigo-500/50 transition-all group"
                    >
                        <div className="flex justify-between items-start mb-6">
                            <div className="p-3 bg-slate-800 rounded-2xl group-hover:bg-indigo-500/10 transition-colors">
                                {p.icon}
                            </div>
                            <div className="text-[10px] bg-slate-800 text-slate-400 px-2 py-1 rounded-md uppercase font-mono tracking-wider">
                                {p.type}
                            </div>
                        </div>
                        <h3 className="text-lg font-bold text-white mb-2">{p.title}</h3>
                        <p className="text-slate-400 text-sm leading-relaxed mb-6">
                            {p.desc}
                        </p>
                        <div className="flex items-center justify-between pt-6 border-t border-slate-800">
                             <div className="flex items-center gap-2">
                                <div className="w-6 h-6 bg-indigo-500/20 rounded-full flex items-center justify-center text-[10px] text-indigo-400 font-bold">
                                    {p.author[0]}
                                </div>
                                <span className="text-xs text-slate-500">{p.author}</span>
                             </div>
                             <button className="text-xs font-bold text-indigo-400 flex items-center gap-1 hover:text-indigo-300">
                                View SDK <ExternalLink className="w-3 h-3" />
                             </button>
                        </div>
                    </motion.div>
                ))}

                {/* Developer CTA */}
                <div className="md:col-span-2 p-12 bg-slate-900/30 border-2 border-dashed border-slate-800 rounded-3xl flex flex-col items-center text-center">
                    <Zap className="w-10 h-10 text-slate-700 mb-4" />
                    <h3 className="text-xl font-bold text-slate-300">Build Your Own Evaluator</h3>
                    <p className="text-slate-500 text-sm max-w-md mx-auto mt-2 mb-8">
                        Our SDK allows you to implement custom `evaluate()` and `mitigate()` methods in TypeScript or Python.
                    </p>
                    <button className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold rounded-lg border border-slate-700 transition-all">
                        Get Started with SDK
                    </button>
                </div>
            </div>
        </div>
    );
}
