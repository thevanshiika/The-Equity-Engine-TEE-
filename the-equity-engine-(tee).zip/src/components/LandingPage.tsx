import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, ArrowRight, Zap, Globe, Cpu, Lock } from 'lucide-react';
import { loginWithGoogle } from '../lib/firebase';

interface Props {
  onStart: () => void;
}

export default function LandingPage({ onStart }: Props) {
  const handleStart = async () => {
    try {
      await loginWithGoogle();
      onStart();
    } catch (e) {
      console.error(e);
    }
  };

  const features = [
    {
      icon: <Zap className="w-6 h-6 text-yellow-400" />,
      title: "Real-time Bias Audit",
      desc: "Instantly detect disparate impact and statistical parity violations in your ML models."
    },
    {
      icon: <Globe className="w-6 h-6 text-blue-400" />,
      title: "Open Innovation",
      desc: "Pluggable fairness definitions for different industries—Hiring, Finance, Healthcare."
    },
    {
      icon: <Cpu className="w-6 h-6 text-purple-400" />,
      title: "Explainable AI",
      desc: "Identify the root features causing bias using our SHAP-powered explainability engine."
    },
    {
      icon: <Lock className="w-6 h-6 text-green-400" />,
      title: "Mitigation Engine",
      desc: "Apply re-weighting and synthetic data balancing to neutralize discriminatory patterns."
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative overflow-hidden"
    >
      {/* Background Orbs */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[10%] right-[-10%] w-[50%] h-[50%] bg-purple-500/10 rounded-full blur-[150px]" />
      </div>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 max-w-7xl mx-auto text-center">
        <motion.div
           initial={{ y: 20, opacity: 0 }}
           animate={{ y: 0, opacity: 1 }}
           transition={{ delay: 0.2 }}
           className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-xs font-mono mb-8"
        >
          <ShieldCheck className="w-3 h-3" />
          UNBIASED AI DECISION - OPEN INNOVATION
        </motion.div>
        
        <motion.h1 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6"
        >
          Audit. Explain. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Mitigate Bias.</span>
        </motion.h1>

        <motion.p 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Historical biases shouldn't define the future. The Equity Engine provides 
          the middleware to detect, measure, and neutralize algorithmic discrimination.
        </motion.p>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button 
            onClick={handleStart}
            className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
          >
            Launch Middleware <ArrowRight className="w-4 h-4" />
          </button>
          <button className="w-full sm:w-auto px-8 py-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl transition-all border border-slate-700">
            Read Whitepaper
          </button>
        </motion.div>
      </section>

      {/* Grid */}
      <section className="py-20 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 bg-slate-900/50 border border-slate-800 rounded-2xl hover:border-indigo-500/50 transition-all group"
            >
              <div className="mb-4 p-3 bg-slate-800/50 rounded-xl w-fit group-hover:scale-110 transition-transform">
                {f.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{f.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-24 bg-slate-900/30 border-y border-slate-800/50">
        <div className="max-w-4xl mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold text-white mb-8">The Problem: Inherited Bias</h2>
            <p className="text-slate-400 leading-relaxed mb-6">
                AI systems used in hiring, finance, and healthcare often inherit historical bias from training data. 
                Without active auditing, these biases create systemic unfairness against underrepresented groups.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12">
                <div className="p-6 rounded-2xl bg-red-500/5 border border-red-500/20">
                    <div className="text-red-400 font-bold text-2xl mb-1">82%</div>
                    <div className="text-xs text-slate-500 uppercase tracking-wider font-mono">Algorithm Bias Cases</div>
                </div>
                <div className="p-6 rounded-2xl bg-orange-500/5 border border-orange-500/20">
                    <div className="text-orange-400 font-bold text-2xl mb-1">$4.2B</div>
                    <div className="text-xs text-slate-500 uppercase tracking-wider font-mono">Economic Impact</div>
                </div>
                <div className="p-6 rounded-2xl bg-indigo-500/5 border border-indigo-500/20">
                    <div className="text-indigo-400 font-bold text-2xl mb-1">0%</div>
                    <div className="text-xs text-slate-500 uppercase tracking-wider font-mono">Safe Without Audits</div>
                </div>
            </div>
        </div>
      </section>
    </motion.div>
  );
}
