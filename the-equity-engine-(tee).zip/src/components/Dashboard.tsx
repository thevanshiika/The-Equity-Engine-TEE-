import React, { useState } from 'react';
import { 
    LayoutDashboard, 
    Upload, 
    Zap, 
    PieChart, 
    FileText, 
    Settings, 
    LogOut,
    Plus,
    Activity,
    ShieldAlert
} from 'lucide-react';
import { auth } from '../lib/firebase';
import { User } from 'firebase/auth';
import { motion, AnimatePresence } from 'framer-motion';
import AuditSection from './AuditSection';
import PluginMarketplace from './PluginMarketplace';
import WhatIfSimulator from './WhatIfSimulator';

interface Props {
  user: User | null;
  onSignOut: () => void;
}

export default function Dashboard({ user, onSignOut }: Props) {
  const [activeView, setActiveView] = useState<'audit' | 'simulator' | 'plugins' | 'history'>('audit');

  const navItems = [
    { id: 'audit', label: 'Bias Audit', icon: <Activity className="w-4 h-4" /> },
    { id: 'simulator', label: 'What-if Lab', icon: <Zap className="w-4 h-4" /> },
    { id: 'plugins', label: 'Innovation Hub', icon: <Plus className="w-4 h-4" /> },
    { id: 'history', label: 'Audit History', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900/50 flex flex-col">
        <div className="p-6 flex items-center gap-3">
          <div className="p-2 bg-indigo-600 rounded-lg">
            <ShieldAlert className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-white tracking-tight">TEE DASHBOARD</span>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                activeView === item.id 
                  ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="bg-slate-800/50 rounded-2xl p-4 flex items-center gap-3 mb-4">
            <img 
                src={user?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.uid}`} 
                alt="User" 
                className="w-10 h-10 rounded-full bg-slate-700"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{user?.displayName || 'User'}</p>
              <p className="text-xs text-slate-500 truncate">{user?.email}</p>
            </div>
          </div>
          <button 
            onClick={() => auth.signOut().then(onSignOut)}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-xl text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/5 transition-all"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
        <div className="p-8 max-w-6xl mx-auto">
          <header className="mb-10">
            <div className="flex items-center gap-2 text-indigo-400 text-xs font-mono uppercase tracking-widest mb-2">
                <Activity className="w-3 h-3" />
                Live Fairness Middleware
            </div>
            <h1 className="text-3xl font-bold text-white">
                {navItems.find(n => n.id === activeView)?.label}
            </h1>
          </header>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
                {activeView === 'audit' && <AuditSection />}
                {activeView === 'simulator' && <WhatIfSimulator />}
                {activeView === 'plugins' && <PluginMarketplace />}
                {activeView === 'history' && (
                    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center">
                        <FileText className="w-12 h-12 text-slate-700 mx-auto mb-4" />
                        <h3 className="text-slate-300 font-bold mb-2">No audits recorded yet</h3>
                        <p className="text-slate-500 text-sm">Upload a dataset to generate your first fairness report.</p>
                    </div>
                )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
