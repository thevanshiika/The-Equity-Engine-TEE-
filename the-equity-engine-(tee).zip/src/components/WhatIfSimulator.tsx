import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
    HelpCircle, 
    Zap, 
    ArrowRightLeft, 
    AlertTriangle,
    CheckCircle2,
    Briefcase,
    GraduationCap,
    Heart,
    MapPin,
    User
} from 'lucide-react';

export default function WhatIfSimulator() {
    const [profile, setProfile] = useState({
        age: 28,
        gender: 'Male',
        location: 'Urban',
        education: "Bachelor's",
        experience: 5
    });

    const [isCalculating, setIsCalculating] = useState(false);
    const [prediction, setPrediction] = useState<'Approved' | 'Denied'>('Approved');

    const handleSimulate = () => {
        setIsCalculating(true);
        // Simple logic simulation: If gender is woman and age < 25, deny (simulating a biased model)
        setTimeout(() => {
            if (profile.gender === 'Female' && profile.age < 30) {
                setPrediction('Denied');
            } else {
                setPrediction('Approved');
            }
            setIsCalculating(false);
        }, 800);
    };

    return (
        <div className="space-y-8">
            <div className="p-6 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-start gap-4">
                <HelpCircle className="w-6 h-6 text-amber-500 shrink-0" />
                <div>
                    <h4 className="text-amber-200 font-bold text-sm">What-if Laboratory</h4>
                    <p className="text-amber-200/60 text-xs mt-1">
                        Experiment with specific demographics to see how your model's prediction flips. 
                        In this prototype, we simulate a model with common age-gender intersectional bias.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Inputs */}
                <div className="lg:col-span-1 space-y-4">
                    <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
                        <div className="space-y-2">
                            <label className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase">
                                <User className="w-3 h-3" /> Gender
                            </label>
                            <div className="flex gap-2">
                                {['Male', 'Female', 'Non-Binary'].map(g => (
                                    <button 
                                        key={g}
                                        onClick={() => setProfile({...profile, gender: g})}
                                        className={`flex-1 py-2 text-xs rounded-lg border transition-all ${profile.gender === g ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600'}`}
                                    >
                                        {g}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase">
                                Age: {profile.age}
                            </label>
                            <input 
                                type="range" 
                                min="18" 
                                max="70" 
                                value={profile.age}
                                onChange={(e) => setProfile({...profile, age: parseInt(e.target.value)})}
                                className="w-full accent-indigo-500"
                            />
                        </div>

                        <div className="space-y-2">
                             <label className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase">
                                <MapPin className="w-3 h-3" /> Location
                            </label>
                             <select 
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white"
                                value={profile.location}
                                onChange={(e) => setProfile({...profile, location: e.target.value})}
                             >
                                <option>Urban</option>
                                <option>Rural</option>
                                <option>Suburban</option>
                             </select>
                        </div>

                        <div className="space-y-2">
                             <label className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase">
                                <GraduationCap className="w-3 h-3" /> Education
                            </label>
                             <select 
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-xs text-white"
                                value={profile.education}
                                onChange={(e) => setProfile({...profile, education: e.target.value})}
                             >
                                <option>High School</option>
                                <option>Bachelor's</option>
                                <option>Master's</option>
                                <option>PhD</option>
                             </select>
                        </div>

                        <button 
                            onClick={handleSimulate}
                            className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 mt-4"
                        >
                            Calculate Prediction
                        </button>
                    </div>
                </div>

                {/* Simulation Display */}
                <div className="lg:col-span-2">
                    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 h-full flex flex-col justify-center items-center relative overflow-hidden">
                        {/* Status lines */}
                        <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent" />
                        
                        {isCalculating ? (
                            <div className="flex flex-col items-center gap-6">
                                <motion.div 
                                    animate={{ rotate: 360 }}
                                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                                    className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full shadow-[0_0_20px_rgba(99,102,241,0.4)]"
                                />
                                <p className="font-mono text-xs text-indigo-400 tracking-[0.2em] uppercase animate-pulse">Running Neural Inference...</p>
                            </div>
                        ) : (
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="text-center space-y-8"
                            >
                                <div className="space-y-2">
                                    <h3 className="text-slate-500 font-mono text-xs uppercase tracking-widest">Model Outcome</h3>
                                    <div className={`text-7xl font-black ${prediction === 'Approved' ? 'text-emerald-400' : 'text-red-400'} drop-shadow-2xl`}>
                                        {prediction.toUpperCase()}
                                    </div>
                                </div>

                                <div className="flex items-center gap-10">
                                    <div className="text-left py-4 px-6 bg-slate-800/50 rounded-2xl border border-slate-700">
                                        <p className="text-[10px] text-slate-500 uppercase font-mono mb-1">Confidence Score</p>
                                        <p className="text-xl font-bold text-white">94.2%</p>
                                    </div>
                                    <div className="text-left py-4 px-6 bg-slate-800/50 rounded-2xl border border-slate-700">
                                        <p className="text-[10px] text-slate-500 uppercase font-mono mb-1">Decision Logic</p>
                                        <p className="text-xl font-bold text-white">Neural-L4</p>
                                    </div>
                                </div>

                                {prediction === 'Denied' && profile.gender === 'Female' && (
                                    <motion.div 
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-200 text-xs"
                                    >
                                        <AlertTriangle className="w-4 h-4 text-red-500" />
                                        <span>Wait! We detected a prediction flip. Changing only 'Gender' caused this denial.</span>
                                    </motion.div>
                                )}
                            </motion.div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
