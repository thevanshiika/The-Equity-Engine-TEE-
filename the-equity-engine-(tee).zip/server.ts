import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // AI Service
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "missing-key");
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

  // API Routes
  app.post("/api/scan-bias", async (req, res) => {
    try {
      const { data, protectedAttribute, targetAttribute } = req.body;
      
      if (!data || !protectedAttribute || !targetAttribute) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // 1. Calculate Statistics
      const privilegedGroup = "Male"; // Placeholder logic for Demo - usually user-selected
      // Real implementation would group by attribute
      
      const analysis = calculateFairnessMetrics(data, protectedAttribute, targetAttribute);
      
      // 2. AI Recommendation
      const prompt = `
        Analyze this AI Bias report and provide recommendations:
        Protected Attribute: ${protectedAttribute}
        Disparate Impact: ${analysis.disparateImpact}
        Statistical Parity Difference: ${analysis.statisticalParityDifference}
        
        Data Summary:
        - Total Rows: ${data.length}
        - Bias Detected: ${analysis.disparateImpact < 0.8 ? "YES" : "NO"}
        
        Provide 3 clear mitigation steps.
      `;
      
      const result = await model.generateContent(prompt);
      const recommendations = result.response.text();

      res.json({
        ...analysis,
        recommendations,
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });

  // Fairness Logic Helper
  function calculateFairnessMetrics(data: any[], protectedAttr: string, targetAttr: string) {
    // Assume binary classification for demo purpose
    // Find unique values in protected attribute
    const groups = Array.from(new Set(data.map(row => row[protectedAttr])));
    if (groups.length < 2) return { error: "Attribute must have at least 2 categories" };

    const privileged = groups[0]; // Simplified
    const unprivileged = groups[1];

    const getOutcomeRate = (group: any) => {
      const groupData = data.filter(row => row[protectedAttr] === group);
      const favorable = groupData.filter(row => row[targetAttr] == 1 || row[targetAttr] === true || String(row[targetAttr]).toLowerCase() === "yes").length;
      return favorable / groupData.length;
    };

    const ratePriv = getOutcomeRate(privileged);
    const rateUnpriv = getOutcomeRate(unprivileged);

    let disparateImpact = 1;
    if (ratePriv > 0) {
        disparateImpact = rateUnpriv / ratePriv;
    } else if (rateUnpriv > 0) {
        disparateImpact = 0; // Privileged group had 0 success while unprivileged had some
    }

    const statisticalParityDifference = rateUnpriv - ratePriv;

    return {
      privilegedGroup: privileged,
      unprivilegedGroup: unprivileged,
      disparateImpact: isNaN(disparateImpact) ? 0 : disparateImpact,
      statisticalParityDifference: isNaN(statisticalParityDifference) ? 0 : statisticalParityDifference,
      fairnessScore: Math.round(Math.max(0, 100 - Math.abs(1 - (isNaN(disparateImpact) ? 1 : disparateImpact)) * 100))
    };
  }

  // Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
